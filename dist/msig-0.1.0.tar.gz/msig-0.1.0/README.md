#MSig

Msig is a method designed to evaluate the statistical significance of motifs from multivariate time series data.

#Highlights


#How to cite
